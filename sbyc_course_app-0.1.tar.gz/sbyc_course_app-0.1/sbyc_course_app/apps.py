from django.apps import AppConfig


class CourseMapsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sbyc_course_app'
