from django.apps import AppConfig


class PortfolioOptimizerConfig(AppConfig):
    name = 'portfolio_optimizer'
